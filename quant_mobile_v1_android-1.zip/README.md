# Quant Mobile V1

这是 Android Studio + Kotlin + Jetpack Compose 的第一版手机界面。

当前包含：
- 首页
- 美股页面
- A股页面
- 回测页面
- 示例股票信号

当前版本**没有实时行情、没有服务器连接、没有自动交易**。

## 打开方式

安装 Android Studio 后：
1. Open 选择本项目文件夹。
2. 等待 Gradle 同步。
3. 连接 Android 手机并开启 USB 调试，或启动模拟器。
4. 点击 Run。

下一阶段：
- 接入之前的 Python 回测引擎
- 建立 FastAPI 后端
- 接入 A股/美股数据
- 登录和数据库
- 定时运行美股夜间/A股早晨扫描
- 推送信号
- 最后再考虑模拟盘和券商 API
