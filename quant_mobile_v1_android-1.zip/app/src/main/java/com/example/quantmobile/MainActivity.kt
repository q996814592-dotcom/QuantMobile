package com.example.quantmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class StockSignal(
    val symbol: String,
    val name: String,
    val market: String,
    val signal: String,
    val note: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuantMobileApp() }
    }
}

@Composable
fun QuantMobileApp() {
    var tab by remember { mutableStateOf(0) }

    val signals = listOf(
        StockSignal("AAPL", "Apple", "美股", "观察", "20日/60日均线状态"),
        StockSignal("600519", "贵州茅台", "A股", "观察", "20日/60日均线状态")
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("首页", "美股", "A股", "回测").forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {},
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(signals, Modifier.padding(padding))
            1 -> MarketScreen("🇺🇸 美股", signals.filter { it.market == "美股" }, Modifier.padding(padding))
            2 -> MarketScreen("🇨🇳 A股", signals.filter { it.market == "A股" }, Modifier.padding(padding))
            else -> BacktestScreen(Modifier.padding(padding))
        }
    }
}

@Composable
fun HomeScreen(signals: List<StockSignal>, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Quant Mobile", style = MaterialTheme.typography.headlineMedium)
            Text("美股夜间 · A股早晨", style = MaterialTheme.typography.bodyLarge)
        }
        item { SummaryCard("🇺🇸 美股", "策略状态：待接入实时数据", "第一版先使用本地示例信号") }
        item { SummaryCard("🇨🇳 A股", "策略状态：待接入实时数据", "下一步接入服务器扫描") }
        item { SummaryCard("📊 回测", "20 / 60 日均线", "历史回测模块准备就绪") }
        item { Text("当前示例信号", style = MaterialTheme.typography.titleLarge) }
        items(signals) { SignalCard(it) }
    }
}

@Composable
fun MarketScreen(title: String, signals: List<StockSignal>, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text(title, style = MaterialTheme.typography.headlineMedium) }
        item { Text("第一版界面：下一步接入 Python 量化服务器。") }
        items(signals) { SignalCard(it) }
    }
}

@Composable
fun BacktestScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("回测", style = MaterialTheme.typography.headlineMedium)
        SummaryCard("策略", "20 / 60 日均线", "信号使用前一交易日数据")
        SummaryCard("资金", "¥100,000", "示例初始资金")
        SummaryCard("结果", "等待运行", "接入 Python 回测引擎后显示收益、回撤和夏普")
        Text("注意：当前 App 不执行任何交易。")
    }
}

@Composable
fun SummaryCard(title: String, main: String, detail: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(main, style = MaterialTheme.typography.titleLarge)
            Text(detail, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun SignalCard(signal: StockSignal) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("${signal.symbol} · ${signal.name}", style = MaterialTheme.typography.titleMedium)
            Text("${signal.market} · ${signal.signal}")
            Text(signal.note)
        }
    }
}
